"""Google ADK agent for the existing CRM Follow-Up project.

The CRM database and business services remain in the existing project.
This file only replaces the old LangGraph/Groq/MCP agent layer with Google ADK.
"""

import asyncio
from google.adk.agents import Agent
from google.adk.apps import App
from google.adk.models import Gemini
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types

from tools import (
    get_dashboard,
    get_customers,
    get_customer,
    get_quotations,
    get_pending_quotations,
    get_purchase_orders,
    get_deliveries,
    get_invoices,
    get_overdue_invoices,
    get_pending_payments,
    get_followups,
    make_payment,
    send_reminder,
)


MODEL = "gemini-3.8-flash"
APP_NAME = "app"


root_agent = Agent(
    name="crm_agent",
    model=Gemini(model=MODEL),
    description=(
        "A CRM assistant that can retrieve CRM information and perform "
        "approved customer, invoice, payment and follow-up actions."
    ),
    instruction="""
You are a helpful CRM assistant for a business.

You can answer normal conversational questions naturally.
If the user says hello, greet them politely.
If the user asks a general knowledge question, answer it normally.

For CRM questions, use the appropriate CRM tool to retrieve the real data.
Never invent customer, quotation, purchase order, delivery, invoice,
payment, or follow-up information.

AVAILABLE CRM TOOLS

- get_dashboard: CRM KPI summary and business analysis.
- get_customers: list all customers.
- get_customer: retrieve one customer by customer ID.
- get_quotations: list quotations.
- get_pending_quotations: quotations that still need action.
- get_purchase_orders: list purchase orders.
- get_deliveries: delivery information and status.
- get_invoices: list invoices.
- get_overdue_invoices: invoices whose payment is overdue.
- get_pending_payments: pending, partial, and overdue payments.
- get_followups: follow-up history.
- make_payment: record a payment when the user explicitly asks to do so.
- send_reminder: send a payment reminder when the user explicitly asks to do so.

TOOL RULES

1. Use a CRM tool whenever the answer requires actual CRM data.
2. For overdue invoice questions, use get_overdue_invoices.
3. For dashboard questions, use get_dashboard.
4. For customer questions, use get_customers or get_customer as appropriate.
5. For invoice/payment questions, use get_invoices, get_overdue_invoices,
   or get_pending_payments as appropriate.
6. Never claim an action was completed unless the tool succeeded.
7. Never send a payment reminder unless the user explicitly requests it.
8. Never record a payment unless the user explicitly requests it.
9. If a tool returns an error, explain the error instead of making up a result.
10. Keep CRM answers concise and easy to read.
11. Use bullet points for multiple records.
12. Display monetary values in Indian Rupees (₹) when appropriate.
""",
    tools=[
        get_dashboard,
        get_customers,
        get_customer,
        get_quotations,
        get_pending_quotations,
        get_purchase_orders,
        get_deliveries,
        get_invoices,
        get_overdue_invoices,
        get_pending_payments,
        get_followups,
        make_payment,
        send_reminder,
    ],
)


# The ADK Web UI discovers root_agent from this module.
app = App(
    name="app",
    root_agent=root_agent,
)


# ---------------------------------------------------------------------------
# Optional backend compatibility helper
# ---------------------------------------------------------------------------
# The existing FastAPI /chat endpoint can call run_agent() without knowing
# anything about the ADK Runner. This keeps the CRM UI working while the
# actual agent is now fully powered by Google ADK.

_session_service = InMemorySessionService()
_runner = Runner(
    app=app,
    session_service=_session_service,
)

_USER_ID = "crm_user"
_SESSION_ID = "crm_web_session"
_session_lock = asyncio.Lock()
_session_ready = False


async def _ensure_session() -> None:
    global _session_ready

    if _session_ready:
        return

    async with _session_lock:
        if _session_ready:
            return

        await _session_service.create_session(
            app_name=APP_NAME,
            user_id=_USER_ID,
            session_id=_SESSION_ID,
        )
        _session_ready = True


async def run_agent(message: str) -> str:
    """Run one user message through the Google ADK CRM agent."""

    await _ensure_session()

    content = types.Content(
        role="user",
        parts=[types.Part.from_text(text=message)],
    )

    final_text = None

    async for event in _runner.run_async(
        user_id=_USER_ID,
        session_id=_SESSION_ID,
        new_message=content,
    ):
        if event.is_final_response() and event.content and event.content.parts:
            parts = [
                part.text
                for part in event.content.parts
                if getattr(part, "text", None)
            ]
            if parts:
                final_text = "\n".join(parts).strip()

    return final_text or "I could not generate a response."
